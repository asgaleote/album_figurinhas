import { Album } from './Album';

export class Usuario {
    Id: number;
    Nome: string;
    Email: string;
    Senha: string;
    Album: Album;
}
export class Album {
    Id: number;
}
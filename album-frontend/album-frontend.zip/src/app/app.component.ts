import { Component, OnInit, OnChanges, ChangeDetectorRef } from '@angular/core';
import { UsuarioService } from './services/usuario.service';
import { Usuario } from './models/Usuario';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'Album de Figurinhas Online'; 
  public loggedUser = false;
  public usuario;

  constructor (
      private router: Router, 
      private route: ActivatedRoute,
      private changeDetector: ChangeDetectorRef
  ) {
  } 

  ngOnInit() {
    if(localStorage.getItem('usuario')){
      this.loggedUser = true;
      this.usuario = JSON.parse(localStorage.getItem('usuario'));
    } else {
      this.router.navigate(['/login'], { relativeTo: this.route })
    }

  }
 
}

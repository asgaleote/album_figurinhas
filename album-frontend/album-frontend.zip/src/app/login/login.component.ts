import { Component, OnInit } from '@angular/core';
import { UsuarioService } from '../services/usuario.service';
import { Usuario } from '../models/Usuario';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private usuarioService: UsuarioService, 
            private router: Router,
            private route: ActivatedRoute ) { }
  private usuario =  <Usuario> { Id: 0,  Email: '', Senha: ''};
  private loggedUser = false;

  ngOnInit() {
    console.log(localStorage.getItem('usuario'), ' usuario retornado');
    if(localStorage.getItem('usuario')){
      
      this.router.navigate(['/'], { relativeTo: this.route });
    }
  }

  onSubmit() {
    this.usuarioService.getUsuarios(this.usuario.Email, this.usuario.Senha)
      .subscribe( (data: Usuario) => {
        let usuarios = data;
        this.usuario = data[0];
        console.log('retornou: ' + this.usuario);
        this.usuario.Senha = '';
        localStorage.setItem('usuario', JSON.stringify(this.usuario) );
        this.router.navigate(['/'], { relativeTo: this.route });
      }); 
      
    // let usuarios = this.usuarioService.getUsuarios();
    // console.log('Usuarios: ' + JSON.stringify(usuarios));
  }

}

import { Injectable } from '@angular/core';
import { Usuario } from '../models/Usuario';
import { HttpClient, HttpParams } from '@angular/common/http';

@Injectable()
export class UsuarioService {

  constructor(private http: HttpClient) { }
  private urlBackend : string = 'https://localhost:5001';  

  getUsuarios(email: string, senha: string): any {    
    
    let paramsUsuario = new HttpParams();

    paramsUsuario.append('email', email);
    paramsUsuario.append('senha', senha);

    return this.http.get(this.urlBackend + '/api/usuario',{ params: paramsUsuario });
  }

  postUsuarios(usuario: Usuario){
    return this.http.post<Usuario>(this.urlBackend + '/api/usuario', usuario);
  }
}

import { Component, OnInit } from '@angular/core';
import { Usuario } from '../models/Usuario';
import { UsuarioService } from '../services/usuario.service';

@Component({
  selector: 'app-cadastro-usuario',
  templateUrl: './cadastro-usuario.component.html',
  styleUrls: ['./cadastro-usuario.component.css']
})
export class CadastroUsuarioComponent implements OnInit {

  private usuario = <Usuario> {};

  constructor(private usuarioService: UsuarioService) { }

  ngOnInit() {
    
  }

  onSubmit(){
    console.log('usuario para cadastrar! ', JSON.stringify(this.usuario));
    this.usuarioService.postUsuarios(this.usuario);
  }
}
